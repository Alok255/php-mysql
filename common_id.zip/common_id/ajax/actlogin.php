<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
 <script>
function showUser(str) {
	alert(str);
    if (str == "") {
        document.getElementById("txthint").innerHTML = " please sletec value";
        return;
    } else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("sam").innerHTML = xmlhttp.responseText;
            }
        }
        xmlhttp.open("GET","get.php?q="+str,true);
        xmlhttp.send();
    }
}
</script>
</head>

<body>
<div id="txthint"></div>
<?php mysql_connect('localhost','root','');
mysql_select_db('samproject');
$sql="select * from samuser";
$rs=mysql_query($sql);
?>
check user <select name="my" id="my" onchange="showUser(this.value)">

<option > select value</option>
<?php 
while($row=mysql_fetch_array($rs))
{
?>
<option value="<?php echo $row[0];?>"> <?php echo $row[1];?></option>
<?php
}?>
</select>

<div id="sam"></div>
</body>
</html>