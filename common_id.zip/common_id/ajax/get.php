<?php

$a=$_GET['q'];
 mysql_connect('localhost','root','');
mysql_select_db('samproject');
$sql="select * from samuser where id=$a";
$rs=mysql_query($sql);
$row=mysql_fetch_array($rs);

?>
<table border="1" width="100%">
<tr>
<td>FILENAME</td><td>Branch </td><td>FILE  </td>
</tr>
<tr>
<td><?php echo $row[1];?> </td><td><?php echo $row[10];?>   </td><td><a href="img/<?php echo $row[5];?>"><img src="img/<?php echo $row[5];?>" height="100"></a></td>
</tr>
</table>
