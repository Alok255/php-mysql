<?php
$a=$_GET['q'];
 mysql_connect('localhost','root','');
mysql_select_db('ajax');
$sql="select * from ajax_example where id=$a";
$rs=mysql_query($sql);
$row=mysql_fetch_array($rs);




?>
<table border="1" width="100%">
<tr>
<td>name  </td><td>rlool  </td>
</tr>
<tr>
<td><?php echo $row[1];?> </td><td><?php echo $row[2];?>   </td><td><?php echo $row[3];?>   </td>
</tr>
</table>
