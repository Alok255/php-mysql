﻿<?php


// include the configs / constants for the database connection
require_once("config/db.php");
?>
<!-- saved from url=(0029)https://www.jugnoo.in/careers -->
<!DOCTYPE html PUBLIC "" ""><HTML 
data-wf-site="538811c92209c0364f2cef3a"><HEAD><META content="IE=11.0000" 
http-equiv="X-UA-Compatible">
     
<META charset="utf-8">     <TITLE>Jugnoo</TITLE>     
<META name="viewport" content="width=device-width initial-scale=1.1 maximum-scale=1.0 user-scalable=yes"> 
    
<META name="description" content="Jugnoo is a friendly ride sharing mobile app.Fast, Affordable and Reliable, Jugnoo offers you a safe ride with just a tap of button."> 
    
<META name="keywords" content="jugnoo,auto app, auto,app">     
<META name="title" content="Jugnoo">     
<META name="viewport" content="width=device-width, initial-scale=1">     <!--<meta name="generator" content="">--> 
    <LINK href="Jugnoo_files/normalize.css" rel="stylesheet" type="text/css">    
 <LINK href="Jugnoo_files/webflow.css" rel="stylesheet" type="text/css">     
<LINK href="Jugnoo_files/jugnoo.webflow.css" rel="stylesheet" type="text/css"> 

<link rel="stylesheet" href="style.css" type="text/css" />


	<!--	<link href="css/style.css" rel='stylesheet' type='text/css' />  --> 
  <!--  <link rel="stylesheet" type="text/css" href="css/style-new.css">-->     
<SCRIPT src="Jugnoo_files/webfont.js"></SCRIPT>
     
<SCRIPT>
        WebFont.load({
            google: {
                families: ["Raleway:100,200,300,regular,500,600,700,800,900"]
            }
        });</SCRIPT>
     
<SCRIPT src="Jugnoo_files/modernizr.js" type="text/javascript"></SCRIPT>
     <LINK href="new-website/assets/favicon_files/logo-small_favicon.png" rel="icon" 
type="image/x-icon">     <LINK href="new-website/assets/favicon_files/logo-small_favicon.png" 
rel="apple-touch-icon">     
<SCRIPT>
        (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function () {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');
        ga('create', 'UA-50866686-1', 'jugnoo.in');
        ga('require', 'displayfeatures');
        ga('require', 'linkid', 'linkid.js');
        ga('send', 'pageview');
    </SCRIPT>
     
<SCRIPT src="Jugnoo_files/jquery-1.11.3.min.js"></SCRIPT>
     
<SCRIPT src="Jugnoo_files/jquery-migrate-1.2.1.min.js"></SCRIPT>
     
<SCRIPT>
        /* function scrollContent(id) {
         $( 'html, body' ).animate({ scrollTop: $( '#' + id ).offset().top }, 800 );
         }*/

        $(document).ready(function () {

            var link = window.location.href.split('#')[1];
            if (link != undefined) {
                var aTag = $("a[name='" + link + "']");

                //console.log($('#header_navigation').height());
                var header_height = $('#header_navigation').height();

                //$('html,body').animate({scrollTop: aTag.offset().top - header_height}, 800);
                var btnid = '#' + link + 'Details';

                var id = $(document).find(btnid).attr('rel');

                $(document).find(btnid).hide();
                $('#' + id).find('.apply_now_btn').show();
                $('#' + id).find('.up_arrow').show();
                $('#' + id).find('.job_description').slideDown(500);
            }
            function scrollToAnchor(aid) {
                var aTag = $("a[name='" + aid + "']");
//                    //console.log(aTag);
                //console.log($('#header_navigation').height());
                var header_height = $('#header_navigation').height();
                $('html,body').animate({scrollTop: aTag.offset().top - header_height}, 800);
            }

            $("a").click(function () {
                var href = $(this).attr('href').replace('#', '')
                scrollToAnchor(href);
            });
        });


        /*
         ================================================================================
         ***********       Career Form validation            ***********
         ================================================================================
         */

        //
        //First Form Validation for Mobile gaming.
        function onSubmitCareer() {
            // Variable declaration
            var gError = false;
            var letters = /^[A-Za-z_ ]+$/;
            var bcName = document.bcForm.bcName.value;
            var bcEmail = document.bcForm.bcEmail.value;
            var atpos = bcEmail.indexOf("@");
            var dotpos = bcEmail.lastIndexOf(".");
            var bcQualification = document.bcForm.bcQualification.value;
            //var bcCollege = document.bcForm.bcCollege.value;
            var numeric = /^[0-9+-]+$/;
            var bcPhone = document.bcForm.bcPhone.value;
            var bcCity = document.bcForm.PreferredLocation.value;
            var cv = document.getElementById('fileInput').value;
            var fileInput = document.getElementById('fileInput');

            // Form field validation
            if (bcName.length == 0) {
                var gError = true;
                document.getElementById("bcName").style.backgroundColor = "#F8CCCC";
                return false;
            }

            if (bcCity.length == 0) {
                var gError = true;
                document.getElementById("PreferredLocation").style.backgroundColor = "#F8CCCC";
                return false;
            }
            if (bcName.match(letters)) {
                document.getElementById("bcName").style.backgroundColor = "white";
            }
            else {
                var gError = true;
                document.getElementById("bcName").style.backgroundColor = "#F8CCCC";
                return false;
            }


            if (bcEmail == 0) {
                document.getElementById("bcEmail").style.backgroundColor = "#F8CCCC";
                return false;
            }

            if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= bcEmail.length) {
                var gError = true;
                document.getElementById("bcEmail").style.backgroundColor = "#F8CCCC";
                return false;
            }
            if (bcEmail != 0) {
                document.getElementById("bcEmail").style.backgroundColor = "white";
            }


            if (bcPhone.match(numeric) || bcPhone == 0) {
            }
            else {
                var gError = true;
                document.getElementById("bcPhone").style.backgroundColor = "#F8CCCC";
                return false;
            }

            if (bcQualification == 0) {
                var gError = true;
                document.getElementById("bcQualification").style.backgroundColor = "#F8CCCC";
                return false;
            }
            else {
                document.getElementById("bcQualification").style.backgroundColor = "white";
            }


            if (cv == '') {
                var gError = true;
                document.getElementById("max_size").innerHTML = "Upload your CV";
                return false;
            }


            for (var i = 0; i < fileInput.files.length; i++) {
                var file = fileInput.files[i];
                if ('size' in file) {
                    var sz = file.size / (1024 * 1024);
                    //RESTRICTING UPLOAD FILE SIZE TO 2MB
                    if (sz >= 2) {
                        //alert('Document is not UPLOADED. Maximum file size is restricted to 2MB.Please try again Uploading other document!!');
                        document.getElementById("max_size").innerHTML = "Upload max-size 2mb";
                        return false;
                    }
                }
            }//for


            if (gError == false) {
                //alert("Sucecss");
                jQuery(".submit").click(function () {
                    this.value = 'Submitting ..';
                    this.disabled = 'disabled';
                });

            }

        }


        jQuery(document).ready(function () {
            jQuery('input.submit').click(function () {
                jQuery('.emailfld').val('Qal1,^c)');
                //return false;
            });
        });


        //Use onclick="slideup('#idname');"
        function slideup(id, a) {
            var header_height = $('#header_navigation').height();
            jQuery('html, body').animate({scrollTop: jQuery('#' + id).offset().top - header_height}, 800);



           /* var selectBox = document.getElementById('PreferredLocation');
            selectBox.innerHTML = "";
            for (var i = 0, l = a.length; i < l; i++) {
                var option = new Option(a[i], a[i], false)
                selectBox.options.add(option);
            }*/
        }

      /*  function changeArray() {
            a = ['Chandigarh', 'Amritsar', 'Ludhiana', 'Jaipur', 'Gurgaon', 'Indore', 'No Preference'];
            var selectBox = document.getElementById('PreferredLocation');
            selectBox.innerHTML = "";
            for (var i = 0, l = a.length; i < l; i++) {
                var option = new Option(a[i], a[i], false)
                selectBox.options.add(option);
            }
        }*/


        //changecolor()
        function changecolor(id) {
            document.getElementById(id).style.backgroundColor = 'white';
        }


        // set the input value of apply for field on button click
        jQuery(document).ready(function () {
            jQuery(".careers_sec button.apply_now_btn").click(function () {
                var apply_for_btn = jQuery(this).attr("rel");
                jQuery('#InterestedIn').val(apply_for_btn);
            });
            $(document).find(".view_details_btn").click(function () {
                var id = $(this).attr('rel');

                $(this).hide();
                $('#' + id).find('.apply_now_btn').show();
                $('#' + id).find('.up_arrow').show();
                $('#' + id).find('.job_description').slideDown(500);


            });
            jQuery(".up_arrow").click(function () {
                var id = $(this).attr('rel');

                $(this).hide();
                $('#' + id).find('.apply_now_btn').hide();
                $('#' + id).find('.view_details_btn').show();
                $('#' + id).find('.job_description').slideUp(500);


            });
            jQuery("#page_1").click(function () {

                $('#page_1').css('color', '#414141');
                $('#page_2').css('color', '#e37727');
                $('#page_3').css('color', '#e37727');
                $('#page_4').css('color', '#e37727');
                $('#page_2_images').hide();
                $('#page_3_images').hide();
                $('#page_4_images').hide();
                $('#team_head_3').hide();
                $('#team_head_2').show();
                $('#page_1_images').fadeIn(1000, function () {
                    slideup('images_top');
                });


            });
            jQuery("#page_2").click(function () {

                $('#page_2').css('color', '#414141');
                $('#page_1').css('color', '#e37727');
                $('#page_3').css('color', '#e37727');
                $('#page_4').css('color', '#e37727');
                $('#page_1_images').hide();
                $('#page_3_images').hide();
                $('#page_4_images').hide();
                $('#team_head_2').show();
                $('#team_head_3').hide();
                $('#page_2_images').fadeIn(1000, function () {
                    slideup('images_top');
                });


            });
            jQuery("#page_3").click(function () {

                $('#page_3').css('color', '#414141');
                $('#page_1').css('color', '#e37727');
                $('#page_2').css('color', '#e37727');
                $('#page_4').css('color', '#e37727');
                $('#page_1_images').hide();
                $('#page_2_images').hide();
                $('#page_4_images').hide();
                $('#team_head_2').hide();
                $('#team_head_3').show();
                $('#page_3_images').fadeIn(1000, function () {
                    slideup('images_top');
                });


            });
            jQuery("#page_4").click(function () {

                $('#page_4').css('color', '#414141');
                $('#page_1').css('color', '#e37727');
                $('#page_2').css('color', '#e37727');
                $('#page_3').css('color', '#e37727');
                $('#page_1_images').hide();
                $('#page_2_images').hide();
                $('#page_3_images').hide();
                $('#team_head_2').hide();
                $('#team_head_3').show();
                $('#page_4_images').fadeIn(1000, function () {
                    slideup('images_top');
                });


            });
            jQuery('.w-nav-link').click(function () {
                $('.w-nav-link').removeClass('active');
                $(this).addClass('active');
            });

        });


    </SCRIPT>
     
<STYLE type="text/css">
        @font-face {
            font-family: lato-regular;
            src: url(fonts/Lato-Regular.ttf);
        }

        @font-face {
            font-family: lato-thin;
            src: url(fonts/Lato-Thin.ttf);
        }

        @font-face {
            font-family: lato-light;
            src: url(fonts/Lato-Light.ttf);
        }

        @font-face {
            font-family: lato-regular;
            src: url(fonts/Lato-Regular.ttf);
        }

        .nav_manu {
            background-color: #e37727 !important;
        }

        @media (max-width: 991px) {
            .nav_manu {
                background-color: #ffffff !important;
            }
        }

        .active {
            font-weight: bolder !important;
            text-decoration: underline !important;
        }

        .careers_sec button.yellow_btn {
            font-size: 18px;
            width: 145px;
            padding: 10px 20px;
            background: #e37727;
            color: #FFF;
            outline: 0;
            border: 0;
            border-radius: 3px;
            /*margin: 0 auto;*/
            display: block;
            margin-top: -60px;
            margin-right: 30px;
            float: right;
            text-align: center;

        }
        .careers_sec a.yellow_btn {
            font-size: 18px;
            width: 145px;
            padding: 10px 20px;
            background: #e37727;
            color: #FFF;
            outline: 0;
            border: 0;
            border-radius: 3px;
            /*margin: 0 auto;*/
            display: block;
            margin-top: -60px;
            margin-right: 30px;
            float: right;
            text-align: center;
        }

        .apply_now_btn {
            margin-right: 90px !important;
        }

        img.up_arrow {
            float: right;
            margin-top: -65px;
            margin-right: 15px;
            display: none;

        }

        .careers_sec {
            width: 100%;
            float: left;
        }

        .careers_sec h1 {
        }

        .careers_sec h2 {
            color: #e37727;
            margin-top: 0px !important;
        }

        .careers_sec hr {
            width: 50%;
            border: 1px solid black;
        }

        div.main_div {
            width: 100%;
            float: left;
        }

        div.job_tagline {
            border-bottom: 1px solid #cecdcd;
            padding-bottom: 10px;
            width: 100%;
            float: left;
        }

        div.job_description {
            padding: 20px 0px;
            border-bottom: 1px solid #5c5a5a;
            display: none;
            width: 100%;
            float: left;

        }

        .careers_sec ul {
        }

        .careers_sec li {
            color: #414141;
            list-style: none;
            list-style-image: url('img/ellipse.png');
            font-size: 18px;
            line-height: 26px;
            font-weight: 300;
        }

        .careers_footer {
        }

        .careers_footer h3 {
            font-size: 50px;
            text-align: left;
            margin-top: 8px;
        }

        .careers_footer p {
            color: #FFF;
            font-size: 23px;
            margin-top: 20px;
        }

        .careers_footer a {
            color: #FFF;
            text-decoration: none;
        }

        p {
            margin-top: 0;
            margin-bottom: 5px;
            color: #414141;
            font-size: 18px;
            font-weight: 300;
            text-align: left;
        }

        h5 {
            margin-top: 20px;
            margin-bottom: 0px;

            color: #414141;
            font-size: 25px;
            line-height: 40px;
            font-weight: 400;
        }

        h1 {
            color: #414141;
            font-size: 46px;
            text-align: left;
        }

        .nav {
            background-color: #e37727 !important;
        }

        .career_post {

        }

        .career_post li {
            font-size: 20px;
        }

        .career_post li a {
            color: #414141;
            text-decoration: none;
            cursor: pointer;
        }

        .career_form ul {
            padding: 0px !important;
        }

        .career_form li {
            float: left;
            width: 46%;
            margin-left: 2%;
            margin-bottom: 17px;
            list-style: none;

        }

        li.c_submit {
            float: none;
            width: 100%;
            margin: 0 auto;
            display: block;
            text-align: center;
        }

        .career_form input[type=text] {
            width: 100%;
            height: 42px;
            padding-left: 7px;
            border: 1px solid #CCC;
            outline: 0;
            line-height: 30px;
            font-size: 16px;
        }

		p{
			
			color:#000;
		}
        .career_form input[type=submit] {
            margin-bottom: 15px;
            width: 175px;
            height: 52px;
            border: none;
            outline: 0;
            background: #e37727;
            color: #FFF;
            font-family: lato-light;
            font-size: 30px;
            cursor: pointer;
            margin: 12px auto;

        }

        .career_form select {
            width: 100%;
            height: 42px;
            padding-left: 7px;
            border: 1px solid rgb(204, 204, 204);
            outline: 0px;
            line-height: 30px;
            font-size: 16px;
            background-color: white;
        }

        .career_dropdown button {
            font-family: exo;
            font-size: 18px;
            padding: 10px 20px;
            background: #FF5B0A;
            color: #FFF;
            outline: 0;
            border: 0;
            border-radius: 3px;
            margin: 0 auto;
            width: 140px;
            display: block;
            margin-top: 40px;
        }

        .career_dropdown button:hover {
            opacity: 0.8;
        }

        .fileinput_button {
            font-size: 16px;
            line-height: 0;
            padding: 20px 20px 20px 20px;
            outline: 0;
            border: 1px solid #CCC;
            background: #ffffff;
            background: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pgo8c3ZnIHhtbG5zPSJod…IgaGVpZ2h0PSIxIiBmaWxsPSJ1cmwoI2dyYWQtdWNnZy1nZW5lcmF0ZWQpIiAvPgo8L3N2Zz4=);
            background: -moz-linear-gradient(top, #ffffff 0%, #eeeeee 50%, #eeeeee 52%, #dddddd 98%);
            background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #ffffff), color-stop(50%, #eeeeee), color-stop(52%, #eeeeee), color-stop(98%, #dddddd));
            background: -webkit-linear-gradient(top, #ffffff 0%, #eeeeee 50%, #eeeeee 52%, #dddddd 98%);
            background: -o-linear-gradient(top, #ffffff 0%, #eeeeee 50%, #eeeeee 52%, #dddddd 98%);
            background: -ms-linear-gradient(top, #ffffff 0%, #eeeeee 50%, #eeeeee 52%, #dddddd 98%);
            background: linear-gradient(to bottom, #ffffff 0%, #eeeeee 50%, #eeeeee 52%, #dddddd 98%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffff', endColorstr='#dddddd', GradientType=0);
        }

        .team_section {
            float: left;
            width: 100%;
            text-align: center;
        }

        .team_section h1 {
            text-align: center;
            color: #e37727;
            font-weight: 500;
        }

        .team_section hr {
            color: #d0cece;
            width: 70%;
            border-style: solid;
        }

        .team_section h2 {
            color: #000;
            text-align: center;
            font-size: 36px;

        }

        .team_section h3 {
            color: #000;
            text-align: center;
            margin: 0px;
            font-size: 21px;
            font-weight: 700;
        }

        .team_images_container {
            width: 100%;
            float: left;
            text-align: center;
        }

        .team_images_container .row {
            width: 100%;
            float: left;
            text-align: center;
            margin-top: 30px;
        }

        .team_images_container .row .team_image {
            width: 25%;
            float: left;
            display: block;
            text-align: center;
        }

        .team_images_container .row .team_image .round_container {
            width: 180px;
            height: 180px;
            border-radius: 90px;
            border: 5px solid #5b5a5a;
            background-color: #f9ba17;
            margin: 0px auto;
        }

        .team_images_container .row .team_image .round_container img {
            width: 170px;
            height: 170px;
            border-radius: 85px;
        }

        .team_images_container .row .team_image p {
            width: 100%;
            text-align: center;
            color: #e37727;
            font-weight: 700;
            font-size: 20px;
            margin-top: 10px;
        }

        .pages_row {
            width: 100%;
            float: left;
            text-align: center;
        }

        .pages_row p {
            width: 100%;
            text-align: center;
            color: #e37727;
            font-weight: 700;
            font-size: 20px;
            margin-top: 10px;
        }

        #why_jugnoo_section {
            width: 100%;
            float: left;
            text-align: center;
        }

        #why_jugnoo_section h1 {
            text-align: center;
            color: #414141;
            font-weight: 400;
        }

        #why_jugnoo_section hr {
            width: 50%;
            color: #414141;
            border: 1px solid #414141;
        }

        #why_jugnoo_section h2 {
            padding-bottom: 10px;
            width: 100%;
            color: #e37727;
            text-align: left;
            border-bottom: 1px solid #cecdcd;
        }

        #why_jugnoo_section .row {
            width: 100%;
            float: left;
            margin-top: 30px;
        }

        #why_jugnoo_section .row .col {
            width: 50%;
            float: left;
            text-align: center;
        }

        #why_jugnoo_section .row .col .col_head {
            width: 100%;
            float: left;
        }

        #why_jugnoo_section .row .col .col_head .col_head_img {
            width: 25%;
            float: left;
        }

        #why_jugnoo_section .row .col .col_head .col_head_heading {
            width: 75%;
            float: left;
            text-align: left;
            padding: 2% 0;
            line-height: 30px;
        }

        #why_jugnoo_section .row .col .col_head .short_head {
            padding: 25px 0px;
        }

        #why_jugnoo_section .row .col .col_head .col_head_heading h3 {
            font-weight: 600;
            text-align: left;
            color: #414141;

            margin: 0px;
        }

        #why_jugnoo_section .row .col .col_head .col_head_content {
            font-size: 18px;
            font-weight: 300;
        }

        #why_jugnoo_section .row .col .col_content {
            float: left;
            width: 100%;
            text-align: justify;
            padding: 10px 10px 10px 70px;
            font-size: 20px;

        }

        #culture_mission_section {
            float: left;
            width: 100%;
        }

        #culture_mission_section h1 {
            color: #414141;
            text-align: center;
            font-weight: 400;
        }

        #culture_mission_section hr {
            color: #414141;
            border: 1px solid #414141;
            width: 70%;
        }

        #culture_mission_section .row {
            width: 100%;
            float: left;
            margin-top: 10px;
        }

        #culture_mission_section .row .col {
            width: 33%;
            float: left;
            padding: 10px;
        }

        #culture_mission_section .row .col .col_head_img {
            width: 100%;
            float: left;
            text-align: center;
        }

        #culture_mission_section .row .col .col_head_heading {
            width: 100%;
            float: left;
            text-align: center;

        }

        #culture_mission_section .row .col .col_head_heading h2 {
            color: #e37727;
        }

        #culture_mission_section .row .col .col_content {
            width: 100%;
            float: left;
            text-align: justify;
            font-size: 18px;
            margin-top: 10px;
            padding: 10px;
        }

        #j_exec_section {
            width: 100%;
            float: left;
        }

        #j_exec_section h1 {
            color: #414141;
            text-align: center;
            font-weight: 400;
        }

        #j_exec_section hr {
            border: 1px solid #414141;
            width: 30%;
        }

        #j_exec_section .row {
            width: 100%;
            float: left;
            margin-top: 20px;

        }

        #j_exec_section .row .col_1 {
            width: 25%;
            float: left;
        }

        #j_exec_section .row .col_1 .col_round_container {
            width: 180px;
            height: 180px;
            border-radius: 90px;
            border: 5px solid #5b5a5a;
            background-color: #f9ba17;
            margin: 0px auto;
        }

        #j_exec_section .row .col_2 {
            width: 75%;
            float: left;
            padding-top: 30px;
            padding-right: 10px;
        }

        #j_exec_section .row .col_2 h4 {
            color: #e37727;
            text-align: left;
            margin-top: 0px;
            margin-bottom: 0px;
            font-weight: 600;
            padding-bottom: 15px;
            font-size: 28px;
        }

        #j_exec_section .row .col_2 p {
            color: #414141;
            font-size: 18px;
        }

        .navtext {
            font-size: 16px !important;
            margin-top: 20px !important;
            color: #ffffff;
        }

        @media (max-width: 991px) {
            .navtext {
                color: #e37727;
            }
        }

        @media screen and (max-width: 800px) {
            .careers_sec hr {
                width: 70%;
                border: 1px solid black;
            }

            .career_form ul {
                padding: 0px;

            }

            .team_images_container .row .team_image {
                width: 50% !important;
            }

            .team_images_container .row .team_image .round_container {
                width: 150px !important;
                height: 150px !important;
                border-radius: 75px !important;
            }

            .team_images_container .row .team_image .round_container img {
                width: 150px !important;
                height: 150px !important;
                border-radius: 75px !important;
            }

            .team_section hr {
                width: 80% !important;
            }

            #why_jugnoo_section hr {
                width: 68% !important;
            }

            #why_jugnoo_section .row .col_head .col_head_img {
                width: 75px !important;
            }

            #why_jugnoo_section .row .col_head .col_head_heading {
                padding: 5px 5px !important;
            }

            #why_jugnoo_section .row .col_head .short_head {
                padding: 25px 5px !important;
            }

            #why_jugnoo_section .row .col_head .col_head_heading h3 {
                font-size: 22px !important;

            }

            #why_jugnoo_section .row .col_content {
                padding: 10px 10px 10px 50px !important;
                font-size: 16px !important;

            }

            #culture_mission_section h1 {
                font-size: 40px !important;
                margin: 0px !important;
            }

            #culture_mission_section hr {
                width: 80% !important;
            }

            #culture_mission_section .row .col .col_head_img img {
                width: 100px !important;
            }

            #culture_mission_section .row .col .col_head_heading h2 {
                font-size: 24px !important;
                font-weight: 800;
            }

            #culture_mission_section .row .col .col_content {
                font-size: 14px !important;
                line-height: 20px !important;

            }

            #j_exec_section h1 {
                color: #414141;
                text-align: center;
                font-size: 30px !important;
            }

            #j_exec_section hr {
                border: 1px solid #414141;
                width: 30%;
            }

            #j_exec_section .row .col_1 {
                width: 30%;
                float: left;
            }

            #j_exec_section .row .col_1 .col_round_container {
                width: 120px;
                height: 120px;
                border-radius: 60px;
                border: 5px solid #5b5a5a;
                background-color: #f9ba17;
                margin: 0px auto;
            }

            #j_exec_section .row .col_2 {
                width: 70%;
                float: left;
                padding-top: 10px;
                padding-left: 10px;
            }

            #j_exec_section .row .col_2 p {

                text-align: justify;
            }

            .w-icon-nav-menu {
                font-size: 40px !important;
            }

        }

        @media screen and (max-width: 603px) {
            .careers_sec hr {
                width: 80%;
                border: 1px solid black;
            }

            .career_form ul {
                padding: 0px;

            }

            .career_form ul li {
                font-size: 14px !important;
            }

            .job_tagline {
                float: left !important;
            }

            p {
                font-size: 16px !important;
                width: 100% !important;
            }

            .yellow_btn {
                margin-top: 0px !important;
                float: right !important;
                width: 100%;
                /*display: block !important;*/
            }

            img.up_arrow {
                /*width: 12% !important;*/
                float: right !important;
                /*display: inline-block !important;*/
                margin-top: -5px;
            }

            .apply_now_btn {
                margin-top: 0px !important;
                float: left !important;
                /*display: block !important;*/
                width: 70% !important;
                margin-right: 0px !important;
            }

            li {
                font-size: 16px !important;
                font-weight: 300;
            }

            h2 {
                font-size: 29px !important;
            }

            .team_images_container .row .team_image {
                width: 50% !important;
            }

            .team_images_container .row .team_image .round_container {
                width: 125px !important;
                height: 125px !important;
                border-radius: 62.5px !important;
            }

            .team_images_container .row .team_image .round_container img {
                width: 125px !important;
                height: 125px !important;
                border-radius: 62.5px !important;
            }

            .team_section hr {
                width: 100% !important;
            }

            .team_section h1 {
                font-size: 40px !important;
            }

            #why_jugnoo_section h1 {
                font-size: 30px !important;
            }

            #why_jugnoo_section hr {
                width: 60% !important;
            }

            #why_jugnoo_section .row .col_head .col_head_img {
                width: 45px !important;
            }

            #why_jugnoo_section .row .col_head .col_head_heading {
                padding: 0px 5px !important;
            }

            #why_jugnoo_section .row .col_head .short_head {
                padding: 10px 5px !important;
            }

            #why_jugnoo_section .row .col_head .col_head_heading h3 {
                font-size: 15px !important;
                line-height: 20px !important;
            }

            #why_jugnoo_section .row .col_content {
                font-size: 13px !important;
                padding: 10px 10px 10px 30px !important;
                line-height: 20px !important;

            }

            #culture_mission_section h1 {
                font-size: 30px !important;
                margin: 0px !important;
            }

            #culture_mission_section hr {
                width: 90% !important;
            }

            #culture_mission_section .row .col .col_head_img img {
                width: 100px !important;
            }

            #culture_mission_section .row .col .col_head_heading h2 {
                font-size: 16px !important;
                font-weight: 800;
            }

            #culture_mission_section .row .col .col_content {
                font-size: 11px !important;
                line-height: 16px !important;
                padding: 0px !important;
            }

            #j_exec_section hr {
                border: 1px solid #414141;
                width: 35%;
            }

        }

        @media screen and (max-width: 414px) {
            .job_tagline {
                float: left !important;
            }

            p {
                font-size: 14px !important;
                width: 100% !important;
            }

            .yellow_btn {
                margin-top: 0px !important;
                float: right !important;
                width: 100%;
                /*display: block !important;*/
            }

            img.up_arrow {
                width: 12% !important;
                float: right !important;
                /*display: inline-block !important;*/
                margin-top: 0px;
            }

            .apply_now_btn {
                margin-top: 0px !important;
                float: left !important;
                /*display: block !important;*/
                width: 70% !important;
                margin-right: 0px !important;
            }

            li {
                font-size: 14px !important;
                font-weight: 300;
            }

            .careers_sec h1 {
                font-size: 30px !important;
            }

            .careers_sec h2 {
                font-size: 25px !important;
            }

            .team_section h1 {
                font-size: 25px !important;
                margin: 0px !important;
            }

            .team_section h2 {
                font-size: 20px !important;
                margin: 0px !important;
            }

            .team_section h3 {
                font-size: 12px !important;
                margin: 0px !important;
            }

            .team_section hr {
                width: 100% !important;
            }

            #why_jugnoo_section {
                margin-top: 30px !important;
            }

            #why_jugnoo_section h1 {
                font-size: 20px !important;
                margin: 0px !important;
                font-weight: 500;
            }

            #why_jugnoo_section h2 {
                font-size: 18px !important;
                margin: 0px !important;
            }

            #why_jugnoo_section hr {
                width: 70% !important;
                margin-top: 0px !important;
                margin-bottom: 0px !important;
            }

            #why_jugnoo_section .row {
                margin-top: 0px !important;
            }

            #why_jugnoo_section .row .col {
                width: 100% !important;
                margin-top: 15px !important;
            }

            #why_jugnoo_section .row .col_head .col_head_img {
                width: 36px !important;
            }

            #why_jugnoo_section .row .col_head .col_head_heading {
                padding: 10px 5px !important;
            }

            #why_jugnoo_section .row .col_head .short_head {
                padding: 10px 5px !important;
            }

            #why_jugnoo_section .row .col_head .col_head_heading h3 {
                font-size: 12px !important;
                line-height: 13px !important;

            }

            #why_jugnoo_section .row .col_content {
                padding: 10px 10px 10px 10px !important;
                font-size: 13px !important;
                line-height: 20px !important;

            }

            #culture_mission_section h1 {
                font-size: 20px !important;
                margin: 0px !important;
                font-weight: 500;
            }

            #culture_mission_section hr {
                width: 90% !important;
            }

            #culture_mission_section .row .col {
                width: 100% !important;
            }

            #culture_mission_section .row .col .col_head_img img {
                width: 120px !important;
            }

            #culture_mission_section .row .col .col_content {
                font-size: 13px !important;
                line-height: 20px !important;
            }

            #j_exec_section h1 {
                color: #414141;
                text-align: center;
                font-size: 30px !important;
            }

            #j_exec_section hr {
                border: 1px solid #414141;
                width: 60%;
            }

            #j_exec_section .row .col_1 {
                width: 30%;
                float: left;
            }

            #j_exec_section .row .col_1 .col_round_container {
                width: 80px;
                height: 80px;
                border-radius: 40px;
                border: 5px solid #5b5a5a;
                background-color: #f9ba17;
                margin: 0px auto;
            }

            #j_exec_section .row .col_2 {
                width: 70%;
                float: left;
                padding-top: 5px;
                padding-left: 5px;
            }

            #j_exec_section .row .col_2 h4 {
                color: #e37727;
                text-align: left;
                margin-top: 0px;
                margin-bottom: 0px;
                font-weight: 600;
                padding-bottom: 10px;
                font-size: 20px;
            }

            #j_exec_section .row .col_2 p {
                color: #414141;
                font-size: 12px;
                text-align: justify;
                line-height: 20px;
            }

            .navlogo {
                height: 35px !important;
                margin: 5px 0px 5px 10px !important;
            }

            .w-nav-button {
                padding: 0px !important;
                margin: 7px 10px 0px 0px !important;
            }

            .w-icon-nav-menu {
                font-size: 30px !important;
            }

            .career_form ul {
                padding: 0px;

            }

            .career_form ul li {
                width: 100%;
                margin-left: 0px !important;
            }

        }

        @media screen and (max-width: 240px) {
            .team_images_container .row .team_image .round_container {
                width: 90px !important;
                height: 90px !important;
                border-radius: 45px !important;
            }

            .team_images_container .row .team_image .round_container p {
                width: 90px !important;
                height: 90px !important;
                border-radius: 45px !important;
            }

            .team_section h1 {
                font-size: 17px !important;

            }

            .team_section h2 {
                font-size: 14px !important;
            }

            .team_section h3 {
                font-size: 8px !important;
            }

            #why_jugnoo_section h1 {
                font-size: 15px !important;
                margin: 0px !important;
            }

            #j_exec_section h1 {
                color: #414141;
                text-align: center;
                font-size: 30px !important;
            }

            #j_exec_section hr {
                border: 1px solid #414141;
                width: 60%;
            }

            #j_exec_section .row .col_1 {
                width: 30%;
                float: left;
            }

            #j_exec_section .row .col_1 .col_round_container {
                width: 40px;
                height: 40px;
                border-radius: 20px;
                border: 5px solid #5b5a5a;
                background-color: #f9ba17;
                margin: 0px auto;
            }

            #j_exec_section .row .col_2 {
                width: 70%;
                float: left;
                padding-top: 5px;
                padding-left: 5px;
            }

            #j_exec_section .row .col_2 h4 {
                color: #e37727;
                text-align: left;
                margin-top: 0px;
                margin-bottom: 0px;
                font-weight: 600;
                padding-bottom: 10px;
                font-size: 15px;
            }

            #j_exec_section .row .col_2 p {
                color: #414141;
                font-size: 10px;
                text-align: justify;
                line-height: 20px;
            }
        }

        /* FOOTER CSS*/
        #footer {
            background-color: #e37727;
            width: 100%;
            color: #fff;
            font-family: lato-regular;
            right: 0;
            bottom: 0;
            left: 0;
            margin-bottom: 0;
        }

        .footerHome {
            position: fixed;
        }

        #footer .container1 {
            padding-top: 8px;
            text-align: center;
        }

        #footer .contactus {
            padding-top: 20px;
            padding-bottom: 10px;
        }

        #footer .copyright {
            margin-bottom: 8px;
            color: #ffffff;
            text-align: center;
        }

        #footer a {
            color: #fff;
            text-decoration: none;
            letter-spacing: 0.5px;
            font-size: 17px;
        }

        .footerSpan {
            font-size: 12px;
        }

        #footer .contactus .col-lg-6 {
            text-align: center;
        }

        @media (max-width: 1200px) {
            .footerHome {
                position: relative;
            }
        }

        @media (max-width: 768px) {

            .navlogo {
                content: url('Images/logo_small.png');
            }

            #footer .container1 {
                padding-top: 5px;
            }

            #footer .contactus {
                padding-top: 15px;
                padding-bottom: 7px;
            }

            #footer .copyright {
                margin-bottom: 0;
            }

            #footer a {
                color: #fff;
                text-decoration: none;
                letter-spacing: 0.5px;
                font-size: 11px;
            }

            .footerSpan, .footerSpan a {
                font-size: 10px;
            }

            #footer .col-lg-6 {
                width: 50%;
                display: inline;
                text-align: center;
                float: left;
            }

            #footer .contactus .col-lg-6 {
                float: none;
                text-align: center;
            }
        }

        queryline {
            font-family: lato-light, color : #e37727;
        }

        .scr-top {
            display: none;
        }


    </STYLE>
     <!-- Latest compiled and minified CSS -->     <LINK href="Jugnoo_files/bootstrap.min.css" 
rel="stylesheet">     <!-- Optional theme -->     <LINK href="Jugnoo_files/bootstrap-theme.min.css" 
rel="stylesheet">     <!-- Latest compiled and minified JavaScript -->     
<SCRIPT src="Jugnoo_files/bootstrap.min.js"></SCRIPT>
 
<META name="GENERATOR" content="MSHTML 11.00.9600.17037"></HEAD> 
<BODY>


<STYLE>
    .row {
        margin-right: 0;
    }
</STYLE>
 
<DIV class="w-nav nav" data-animation="default" data-collapse="medium" 
data-contain="1" data-duration="400">
<DIV class="w-container" id="header_navigation" style="text-align: center;"><A 
href="index.php"><IMG class="navlogo" style="width: auto; height: 70px; float: left;" 
alt="" src="Jugnoo_files/logo.png">         </A>         <NAV class="w-nav-menu nav_manu" 
role="navigation"><A class="w-nav-link navtext" style="font-family: lato-light,sans-serif; font-weight: 300; text-decoration: none;" 
href="login.php">Login</A>   
          <A class="w-nav-link navtext" style="font-family:'Comic Sans MS', cursive; font-weight: 300; text-decoration: none;" 
href="https://www.jugnoo.in/careers#j_exec">Contact Us</A>         </NAV>         
<DIV class="w-nav-button nav-menu" style="background: none;">
<DIV class="w-icon-nav-menu" 
style="color: rgb(255, 255, 255);"></DIV></DIV></DIV></DIV>
<DIV class="w-container container" style="padding-right: 0px !important; padding-left: 30px !important;" 
data-ix="show-nav"><A class="scr-top" style="height: auto; right: 20px; bottom: 100px; position: fixed; z-index: 5000; opacity: 0.5;" 
href="https://www.jugnoo.in/careers#why_jugnoo"><IMG 
src="Jugnoo_files/top.png"></A>     
<DIV class="w-row"><!--Why Jugnoo Section Starts-->         
<DIV id="why_jugnoo_section" style="margin-top: 75px;"><A name="why_jugnoo"></A> 
            
<DIV class="careers_sec" style="padding-right: 15px; margin-left: -10px; float: left;">
 
<H1 align="center" style="font-family:'Comic Sans MS', cursive;">COMMON Id</H1>

<BR>
<H2>Sign Up</H2></DIV>
<DIV class="why_jugnoo_content"></DIV></DIV><!--Why Jugnoo Section Ends-->
<!--J Exec Section starts--> 
        
<DIV id="j_exec_section">
  <p><A name="j_exec"></A></p>
  
                            <center><!-- header ends here -->
<div class="loginbox radius">
  <h2 style="color:#141823; text-align:center;">&nbsp;</h2>
  <div class="loginboxinner radius">
    <?php  
     $remarks  =  isset($_GET['remarks'])  ?  $_GET['remarks']  :  '';
     if  ($remarks==null  and  $remarks=="")
{
  /* echo  '
<div  id="reg-head"  class="headrg">Register  Here</div>
 
'; */
       }
     if  ($remarks=='success')
{
   echo  '
<div  id="reg-head"  class="headrg">Registration  Success</div>
 
';
       }
     if  ($remarks=='failed')
{
   echo  '
<div  id="reg-head-fail"  class="headrg">Registration  Failed!,  Username  exists</div>
 
';
       }
?>
</div>
		<?php  
     $remarks  =  isset($_GET['remarks'])  ?  $_GET['remarks']  :  '';
     if  ($remarks==null  and  $remarks=="")
{
   echo  '
<div  id="reg-head"  class="headrg">Register  Here</div>
 
';
       }
     if  ($remarks=='success')
{
   echo  '
<div  id="reg-head"  class="headrg">Registration  Success</div>
 
';
       }
     if  ($remarks=='failed')
{
   echo  '
<div  id="reg-head-fail"  class="headrg">Registration  Failed!,  Username  exists</div>
 
';
       }
?>
    <!--loginheader-->
    <div class="loginform">
    
      <br>
      <form name="reg" action="execute.php" onsubmit="return  validateForm()"  method="post"  id="reg">
        
 	<table align="center" cellpadding="2" cellspacing="0">
    
    <tr>
    <td style="color:#000 class="t-1">
    <div align="left" id="tb-name">First Nmae:</div></td>
    <td width="121"><input type="text" name="fname" id="tb-box" />
    </tr>
    <tr>
    <td class="t-1"><div align="left" id="tb-name">LastName:</div>
    
    <td><input type="text" name="lname" id="tb-box" /></td>
    </tr>
    
    <tr>
    <td class="t-1">
    <div align="left" id="tb-name">Email:</div>
    <td><input type="text" id="tb-box" name="address" />
    </tr>
    
    <tr>
    <td class="t-1">
    <div align="left" id="tb-name">Username</div>
    </td>
    
    <td><input  type="text"  id="tb-box"  name="username"  /></td>
 
   </tr>
 
 
<tr>
 
<td  class="t-1">
<div  align="left"  id="tb-name">Password:</div>
</td>
 
 
<td><input  id="tb-box"  type="password"  name="password"  /></td>
  <td> <select name="branch" id="branch" class="radius title">
  <option value="cse">CSE</option>
  <option value="me">ME</option>
  <option value="ec">EC</option>
  <option value="ce">CE</option>
</select></td>
 
   </tr>
 
</table>
 
 
<div  id="st"><input  name="submit"  type="submit"  value="Submit"  id="st-btn"/></div>
 
</form>
    </div> 
        </div>
        </div>
    <!--loginform-->

  <!--loginboxinner-->

                          </center>
					</div>
					<div class="Login">
		<div class="Login-head">
			
						 	</div>
  </div>&nbsp;</p>
</DIV>

<DIV class="row">
</DIV>
</DIV></DIV>
<DIV class="row">
</DIV></DIV></DIV><!--J Exec Section Ends-->    
     <!--Career Section Starts-->         
     
     <!--Career Form Starts--> 
            
<DIV class="career_form" id="c_sec4" style="width: 100%; float: left;"></DIV><!--Career Form Ends--> 
        </DIV><!--Career Section Ends-->         
 </DIV></DIV>
<DIV id="footer">
<DIV class="w-container container1">
<DIV class="row" style="padding-top: 8px;">
<DIV class="col-lg-4 col-sm-4" style="padding-left: 5px;">
<DIV class="col-lg-6"><A href="">ABOUT US</A></DIV>     
            
<DIV class="col-lg-6"><A href="#">CAREERS</A></DIV>  
           </DIV>
<DIV class="col-lg-4 col-sm-4" style="padding-left: 5px;">
<DIV class="col-lg-6"><A href="#">PRESS 
MEDIA</A></DIV>                 
<DIV class="col-lg-6"><A 
href="#">INVESTORS</A></DIV>             </DIV>
<DIV class="col-lg-4 col-sm-4" style="padding: 0%;">
<DIV class="col-lg-6"><A href="#">HELP 
CENTER</A></DIV>                 
<DIV class="col-lg-6"><A href="#">CONTACT 
US</A></DIV>             </DIV></DIV>
<DIV class="row contactus">
<DIV class="col-lg-3"></DIV>
<DIV class="col-lg-6"><A href="#" target="_blank"><IMG 
width="50" height="50" style="margin-right: 0px;" alt="Fb" src="Jugnoo_files/fb.png"></A> 
                <A href="#" target="_blank"><IMG 
width="50" height="50" style="margin-left: 15px;" alt="Blog" src="Jugnoo_files/blog.png"></A> 
                <A href="#" target="_blank"><IMG 
width="50" height="50" style="margin-left: 15px;" alt="Blog" src="Jugnoo_files/t-icon.png"></A> 
                <A href="#" 
target="_blank"><IMG width="50" height="50" style="margin-left: 15px;" alt="Blog" 
src="Jugnoo_files/i-icon.png"></A>             </DIV>             
<DIV class="col-lg-3"></DIV></DIV>
<DIV class="row copyright">
<DIV class="col-lg-12"><SPAN class="footerSpan">© 2015 COMMON Id - <A href="#">TERMS</A> 
- <A href="https://jugnoo.in/#/privacy">PRIVACY</A></SPAN>             
</DIV></DIV></DIV></DIV><!--[if lte IE 9]>
<
 </BODY></HTML>
