<?php
$conn=mysqli_connect('mysql.hostinger.in','u342250270_root','samcet4@');
mysql_select_db('u342250270_commo');

if(isset($_POST['ok']))

{
 $p=$_FILES['file']['name'];
move_uploaded_file($_FILES['file']['tmp_name'],"img/".$p);
 
$sql="INSERT INTO samuser (filename, branch,sem,file)
VALUES
('$_POST[filename]','$_POST[Branch]','$_POST[Semester]','$p')";
$rs=mysqli_query($sql) or die(mysqli_error());
if($rs>0)

header('location:upload.php');	

}
//This code is generate auto uid from Database
$sql="select max(uid) from todaytable";
$rs=mysqli_query($sql);
$row=mysql_fetch_array($rs);
$r=$row[0]+1;

?>
