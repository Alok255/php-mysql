
<?php
$con = mysqli_connect("mysql.hostinger.in","u342250270_root","samcet4@");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 
mysqli_select_db("u342250270_commo", $con);

if(isset($_POST['ok']))
{
 
 $p=$_FILES['file']['name'];
move_uploaded_file($_FILES['file']['tmp_name'],"img/".$p);
 
$sql="INSERT INTO samuser (filename, branch,sem,file)
VALUES
('$_POST[filename]','$_POST[Branch]','$_POST[Semester]','$p')";
}
 
if (!mysqli_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }
echo "1 record added";
 
mysqli_close($con)

?>