

<!DOCTYPE html>
<html>
	<head>	
		<title></title>
		
		<!--webfonts-->
	</head>
	<body>	
	<center>
	<!--start-login-form-->

	
	<!--//End-login-form-->
			 
						  
						    	<h2><span></span>Upload Doc's </h2>
					 	    </div>
							
				
							
	<form method="post" action="up.php" enctype="multipart/form-data">
							
						  		<input type="text" value="File Name" name="filename" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'File Name';}" >
						  		<br></br>
<p  style="color:white;"> Select Branch</p><select name="Branch" class="select">
  <option value="cse"><a href="#">CSE</a></option>
  <option value="me"><a herf="#">ME</a></option>
  <option value="ce"><a href="#">CE</a></option>
  <option value="ce"><a href="#">EC</a></option>
</select> 
<br></br>
<p style="color:white;">Select Semester</p><select name="Semester" class="select">
  <option value="I"><a href="#">I</a></option>
  <option value="II"><a herf="#">II</a></option>
  <option value="III"><a href="#">III</a></option>
  <option value="IV"><a href="#">IV</a></option>
  <option value="V"><a href="#">V</a></option>
  <option value="VI"><a herf="#">VI</a></option>
  <option value="VII"><a href="#">VII</a></option>
  <option value="VIII"><a href="#">VIII</a></option>
</select>           
<br></br>
<input type ="file" name="file">
      
								 <div class="Remember-me">
								<div class="p-container">
								<div class ="clear"></div>
							</div>
												 
								
									<a><button name="ok" type="submit"><img src="upload.png"/ ></button></a>
								
									<div class="clear"> </div>
								</div>
											
						  </form>					
    </center>
	



	</body>
</html>


