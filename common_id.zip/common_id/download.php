<?php
include "db.php";

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="100%" border="1">
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td width="19%" height="288"><p>my menu</p>
  <?php include("menu.php"); ?></p>
    </td>
    <td width="81%" valign="top">
    <table border="1" width="100%">
    <tr>
    <td> Sno </td>
    <td> news title </td>
    
    <td> action </td>
     </tr>
     
     <?php
	 $i=1;
	 $sql="select * from samuser";
	 $rs=mysql_query($sql) or die(mysql_error());
	 while($row=mysql_fetch_array($rs))
	 {
	 ?>
    <tr>
    <td><?php echo $i++;?> </td>
    <td><?php echo $row[1];?> </td>
    <td><a href="delete.php?id=<?php echo $row[1];?>"> delete </a>| <a href="update.php?id=<?php echo $row[1];?>"> edit </a> </td>
    
    </tr>
    
    <?php
	 }?>
    
    </table>
    
    
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

</body>
</html>