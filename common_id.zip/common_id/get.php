 <html>
<head>
<script>
function showUser(str) {
    if (str == "") {
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","getuser.php?q="+str,true);
        xmlhttp.send();
    }
}
</script>
</head>
<body>

<form>
<select name="users" onchange="showUser(this.value)">
  <option value="">Select a person:</option>
  <option value="1">Peter Griffin</option>
  <option value="2">Lois Griffin</option>
  <option value="3">Joseph Swanson</option>
  <option value="4">Glenn Quagmire</option>
  </select>
</form>

<?php mysql_connect('localhost','root','');
mysql_select_db('user_profile');
$sql="select * from samuser";
$rs=mysql_query($sql);
?>
<select name="my" id="my" onchange="showUser(this.value)">

<option > select value</option>
 <?php
while($row=mysql_fetch_array($rs))
{
?>
<option value="<?php echo $row[0];?>"> <?php echo $row[2];?></option>
<?php
}?>
</select>
<br>
<div id="txtHint"><b>Person info will be listed here...</b></div>

</body>
</html>