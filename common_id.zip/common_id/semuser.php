
<?php include('session.php'); ?>
<?php
ob_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<body>
<h1> User Registration form </h1>
<form action="" method="post" enctype="multipart/form-data">
<table width="100%" border="1">
  <tr>
    <td> user name </td>
    <td><input type="text" name="uname" placeholder="please input user name" /></td>
  </tr>
  <tr>
    <td>password </td>
    <td>
    <input type="text" name="upass"  />
    </td>
  </tr>
  <tr>
    <td>user type</td>
   <input type="text" name="sem" />
  </tr>
  <tr>
    <td>
    address 
    </td>
    
  </tr>
  <tr>
    <td>profile pic</td>
    <td><input type="file" name="file" /></td>
	
<input type="hidden" name="username" value="<?php  echo  $loggedin_session;  ?>" />
  </tr>
  <tr>
  <td colspan="2"><input type="submit" name="ok" /></td>
  </tr>
</table>



</form>
</body>
</html>
<?php
include ('db.php');

if(isset($_POST['ok']))
{
$a=$_POST['uname'];
$b=md5($_POST['upass']);
$c=$_POST['sem'];

$p=$_FILES['file']['name'];	
move_uploaded_file($_FILES['file']['tmp_name'],"img/".$p);
$d=$_POST['username'];	
$sql="insert into samuser(uname,filename,branch,sem,file) values('$d','$a','$b','$c','$p')";
mysql_query($sql) or die(mysql_error());
//header('location:login.php');	
	
}


?>