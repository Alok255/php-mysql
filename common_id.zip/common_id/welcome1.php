<?php
/*
<?php include('session.php'); ?>
<!DOCTYPE  html>
<html>
<head>

<title>Profile</title>

<script src="ckeditor/ckeditor.js"></script>
	<script src="ckeditor/samples/js/sample.js"></script>

	<link rel="stylesheet" href="ckeditor/samples/toolbarconfigurator/lib/codemirror/neo.css">
</head>
<body> 
 
<div  id="center">
 
<div  id="center-set">
<h1  align='center'>Welcome  <?php  echo  $loggedin_session;  ?>,</h1>
<br></br><td  class="tl-4">
 
  You  are  now  logged  in.  you  can  logout  by  clicking  on  signout  link  given  below.
 
 
<div  id="contentbox">
<?php include('db.php');
 $sql="SELECT  *  FROM  member  where  mem_id=$loggedin_id"; 
$result=mysql_query($sql); 
 while($rows=mysql_fetch_array($result)){ 
 ?>
 
<div  id="signup">
 
<div  id="signup-st">
 <?php
  echo $rows['mem_id'];
   echo $rows['fname'];
	echo"<br></br>";
	echo $rows['lname'];
 }?>
<div  id=""  class="">Your  Profile</div>
 
 
<table  border="0"  align="center"  cellpadding="2"  cellspacing="0">
 
<tr  id="">
<td  class="">
<div  align="left"  id="">Reg  id:</div>
</td>
<table  border="0"  align="center"  cellpadding="2"  cellspacing="0">
 
<tr  id="lg-1">
 
<td  class="tl-1">
<div  align="left"  id="">Reg  id:</div>
</td>
 
 
<td  class="tl-4"><p style="font-size:18px; font-family:Verdana, Geneva, sans-serif;"><?php  echo  $rows['mem_id'];  ?></p></td>
 
</tr>
 
 
<tr  id="lg-1">
 
<td  class="tl-1">
<div  align="left"  id="">Name:</div>
</td>
 
 

</tr>
 
 
<tr  id="lg-1">
 
<td  class="">
<div  align="left"  id="tbe">Email  id:</div>
</td>
 
 
<td  class="t"><?php  echo  $rows['address'];  ?></td>
 
</tr>
 
 
<tr  id="-1">
 
<td  class="-1">
<div  align="left" >Gender:</div>
</td>
 
 
<td  class="4"><?php  echo  $rows['gender'];  ?></td>
 
</tr>
 <br />
 
 <?php
 /*
$conn=mysqli_connect('localhost','root','');
mysql_select_db('user_profile');
ob_start();


if(isset($_POST['ok']))
{
//$id=$_POST['id'];

$id1=$_POST['id'];
$a=$_POST['msg'];
//$sql="insert into member text='$a' where mem_id=$t";
$sql="INSERT INTO member VALUES ($rows[msg]) where mem_id=$id1";
mysql_query($sql) or die(mysql_error());
header('location:welcome.php');
}


?>
<form method="post" action="textare.php">
<?php echo $rows['mem_id'];?>
<input type="heddin" name="id" value="<?php echo $rows['mem_id'];?>" /><br />
<textarea id="editor" cols="50" rows="20" name="msg".>

</textarea>
<input type="submit" name="ok" />
</form>
	
<script>
	initSample();
</script>

</table>
 
 
 
</form>
 
</div>
 
</div>
 
 
<div  id="login">
 
<div  id="login-sg">
 
<div  id="st"><a  href="logout.php"  id="st-btn">Sign  Out</a></div>
 
 
<div  id="st"><a  href="deleteac.php"  id="st-btn">Delete  Account</a></div>
 
</div>
 
</div>
 
<?php  } ?>
</div>
 
</div>
 
</div>
 
<?php //  close  connection; mysql_close(); ?>
</br>
 
<div  id="footer">
 
 
</div>
 
</body>
</html>
*/
?>
<?php include('session.php'); ?>
<!DOCTYPE  html>
<html>
<head>
<meta  content='text/html;  charset=UTF-8'  http-equiv='Content-Type'/>
<link  rel="stylesheet"  type="text/css"  href="style.css"  />

<script src="ckeditor/ckeditor.js"></script>
	<script src="ckeditor/samples/js/sample.js"></script>

<script src="ckeditor/ckeditor.js"></script>
	<script src="ckeditor/samples/js/sample.js"></script>

<title><?php $a=DATE("D-M-Y"); 
echo $a;
?>  College Login</title>
</head>
<body>
<div  id="center">
 
<div  id="center-set">
<h1  align='center'>Welcome  <?php  echo  $loggedin_session;  ?>,</h1>
 
 
 
  You  are  now  logged  in.  you  can  logout  by  clicking  on  signout  link  given  below.
 
 
<div  id="contentbox">
<?php include('db.php'); $sql="SELECT  *  FROM  member  where  mem_id=$loggedin_id"; $result=mysql_query($sql); ?>
<?php while($rows=mysql_fetch_array($result)){ ?>
 
<div  id="signup">
 
<div  id="signup-st">
 
<form  action=""  method="POST"  id="signin"  id="reg">
 
<div  id="reg-head"  class="headrg">Your  Profile</div>
 
 
<table  border="0"  align="center"  cellpadding="2"  cellspacing="0">
 
<tr  id="lg-1">
 
<td  class="tl-1">
<div  align="left"  id="tb-name">Reg  id:</div>
</td>
 
 
<td  class="tl-4"><?php  echo  $rows['mem_id'];  ?></td>
 
</tr>
 
 
<tr  id="lg-1">
 
<td  class="tl-1">
<div  align="left"  id="tb-name">Name:</div>
</td>
 
 
<td  class="tl-4"><?php  echo  $rows['fname'];  ?>  <?php  echo  $rows['lname'];  ?></td>
 
</tr>
 
 
<tr  id="lg-1">
 
<td  class="tl-1">
<div  align="left"  id="tb-name">Email  id:</div>
</td>
 
 
<td  class="tl-4"><?php  echo  $rows['address'];  ?></td>
 
</tr>
 
 
<tr  id="lg-1">
 
<td  class="tl-1">
<div  align="left"  id="tb-name">Gender:</div>
</td>
 
 
<td  class="tl-4"><?php  echo  $rows['gender'];  ?></td>
 
</tr>
 
</table>
 
 


</form>
 
</div>
 
</div>
 
 
<div  id="login">
 
<div  id="login-sg">
 
<div  id="st"><a  href="logout.php"  id="st-btn">Sign  Out</a></div>
 
 
<div  id="st"><a  href="deleteac.php"  id="st-btn">Delete  Account</a></div>
 
</div>
 
</div>
 
<?php  } ?>
</div>
 
</div>
 
</div>
 
<?php //  close  connection; mysql_close(); ?>
</br>
 
<div  id="footer">
 
 
Copyright  &copy;  2014-<?php $a=DATE("y"); 
echo $a;
?>  &trade;
 
</div>
 
</body>
</html>

