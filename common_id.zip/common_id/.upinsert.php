
<?php
$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 
mysql_select_db("user_profile", $con);

if(isset($_POST['ok']))
{
 
 $p=$_FILES['file']['name'];
move_uploaded_file($_FILES['file']['tmp_name'],"img/".$p);
$a=$_POST['username'];
 
$sql="INSERT INTO samuser (filename, branch,sem,file,uname)
VALUES
('$_POST[filename]','$_POST[Branch]','$_POST[Semester]','$p','$a')";
}
 
if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }
echo "1 record added";
 
mysql_close($con)

?>