-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 06, 2016 at 09:11 AM
-- Server version: 5.5.36
-- PHP Version: 5.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `user_profile`
--

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `mem_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `gender` text NOT NULL,
  PRIMARY KEY (`mem_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`mem_id`, `username`, `password`, `fname`, `lname`, `address`, `gender`) VALUES
(1, 'alok2', '123456', 'Alok', 'Singh', 'alok@gmail.com', ''),
(4, 'addy', '12345', 'Addy', 'N', 'addy@dmai.com', ''),
(3, 'ravi1', '12345', 'Ravindra', 'Singh', 'ravi@gmail.com', ''),
(7, 'alok1', 'alok2', 'alok', '', '', ''),
(13, 'alokraj12', '123456', '', 'Singh', 'alok@gmail.com', ''),
(21, 'addysingh', '123456', 'Alok', 'Singh', 'alok@gmail.com', ''),
(12, 'alokraj', '123456', 'Alok', 'Singh', 'alok@gmail.com', 'Male'),
(16, 'ffsfsfs', 'sfsfsf', 'fsfs', '', 'sfsf@f.ff', ''),
(17, 'ffsfsffsf', '', '', '', 'sfsf@f.ff', ''),
(19, 'sachin', '123456', 'Sachin', 'Dey', 'sachin@dey.gmail', ''),
(22, 'ravi', '123456', 'ALok', 'Singh', 'add@singh.com', ''),
(23, '123456', '123456', '12233555', '5131', 'alok@gmail.com', 'ec'),
(24, '123', '123', '123', '1234', 'alok@gmail.com', 'cse'),
(27, 'aloksam', '123456', 'Alok', 'Singh', 'aloksig', 'cse'),
(26, 'alok43', '`1234', 'Alok', 'fgfg', 'jhkjhkj', 'cse'),
(28, 'Aloksamcet', '123456', 'Alok', 'Singh', 'aloksig@ff.ff', 'cse');

-- --------------------------------------------------------

--
-- Table structure for table `samuser`
--

CREATE TABLE IF NOT EXISTS `samuser` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `sem` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `samuser`
--

INSERT INTO `samuser` (`id`, `filename`, `branch`, `sem`, `file`) VALUES
(12, 'Alok', 'me', 'IV', 'WindowBackUp.png'),
(13, 'Alok', 'cse', 'I', 'Screenshot (7).png'),
(14, 'FaceBook', 'cse', 'I', 'Screenshot (7).png'),
(15, 'FaceBook', 'me', 'V', 'WindowBackUp.png'),
(16, 'FaceBook', 'cse', 'I', 'Screenshot (1).png'),
(17, 'Project Done', 'cse', 'III', 'IMG_20160709_153119.jpg'),
(18, 'Alok test', 'ce', 'VIII', 'C360_2016-07-09-17-04-49-923.jpg'),
(19, 'Alok test', 'ce', 'VIII', 'C360_2016-07-09-17-04-49-923.jpg'),
(20, 'FaceBook', 'cse', 'I', 'WindowBackUp.png'),
(21, 'FaceBook', 'cse', 'I', 'Screenshot (4).png'),
(22, 'Alok', 'ce', 'IV', ''),
(23, 'Alok', 'ce', 'IV', ''),
(24, 'FaceBook', 'cse', 'I', ''),
(25, 'gtyvjhbkm', 'me', 'V', ''),
(26, 'kjkjkj', 'bf59b54ff5c0e87ee7004d35df98fba2', ',mnvdfkjnvkj', 'Screenshot (1).png'),
(27, 'kkkj', 'c1a38c39a9cafb37f9602d69a29848cd', 'fvf', 'Screenshot (2).png');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
